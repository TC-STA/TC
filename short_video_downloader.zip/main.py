from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from download import download_video
from utils import extract_url_info

class RootWidget(BoxLayout):
    def process_input(self):
        user_input = self.ids.input_box.text
        url = extract_url_info(user_input)
        if url:
            self.ids.status_label.text = f"识别到链接: {url}"
            try:
                download_video(url)
                self.ids.status_label.text = "下载完成 🎉"
            except Exception as e:
                self.ids.status_label.text = f"下载失败: {str(e)}"
        else:
            self.ids.status_label.text = "未识别到有效链接"

class ShortVideoApp(App):
    def build(self):
        return RootWidget()

if __name__ == '__main__':
    ShortVideoApp().run()