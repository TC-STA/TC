import yt_dlp

def download_video(url):
    ydl_opts = {
        'outtmpl': '/sdcard/Download/%(title)s.%(ext)s',
        'format': 'mp4',
        'quiet': True,
        'noplaylist': True,
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])